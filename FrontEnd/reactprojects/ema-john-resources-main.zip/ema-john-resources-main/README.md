# ema-john-resources

### Fake data link: 
use this link to load data: 
[https://raw.githubusercontent.com/ProgrammingHero1/ema-john-resources/main/fakeData/products.json](https://raw.githubusercontent.com/ProgrammingHero1/ema-john-resources/main/fakeData/products.json)
